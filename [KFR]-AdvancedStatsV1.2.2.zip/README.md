
1. Drag the files into your corebot directory
AdvancedStats.js -> Addons
59Utils.js -> Main Directory (Always update this file)
2. UPDATE 59Utils.js THIS IS IMPORTANT
3. Delete/backup your old advancedstats config (if applicable)
3. boot up your bot

Commands:
 -vctop <page> - shows top vc times
 -msgtop <page> - shows top message count
 -top <messages/vc> <page> - shows top messages/vctime
 -profile - shows old corebot profile + vctime & messages
 -ticketstats <user> - shows ticket stats, MAY BE SLOW OR CAUSE LAG | IDK
