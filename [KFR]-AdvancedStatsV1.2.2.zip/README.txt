Features:

-Voice Chat Timer
-Ignore Muted & Deafened users
-Minimum Required Users In Vc
-Voice Time Roles
-Message Counter
-Message Count Roles
-Advanced Profile Command
-Advanced Invites Support
-Advanced Boosters Support
  Ticket Counter
	24 Hour Ticket Stats
	7 Days Ticket Stats
	30 Days Ticket Stats
	All Time Ticket Stats
	Ticket Close Counter
	Tickets Spoken Counter

Commands:

top <messages/vc> - shop top mixed or seperated messages and vc time
msgtop - show top messages
vctop - show top vc time
profile - see your vc time and message count
ticketstats - see a users ticketstats (May be laggy/slow)